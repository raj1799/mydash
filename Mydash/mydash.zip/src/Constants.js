export const alphaNumericValidation = "Please provide validate alphanumeric character minimum three";
export const emailValidation = "Please provide validate email example xxx@gmail.com";
export const passwordValidation="Please provide password with minimum one digit one small case and one capital case";
export const phonenumbervalidation="please provide your ten digit (india) mobile number";