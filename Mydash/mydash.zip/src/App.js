
import './App.css';
import Register from './Components/Register/Register';
import Bar from './Components/Bar/Bar';



import './Assests/font-awesome/css/font-awesome.min.css';

import {BrowserRouter,Routes, Route} from 'react-router-dom';




function App(){
   return (<div className="App">
  <BrowserRouter>
 
  <Routes>
     <Route path="/" element={<Register/>}/>
     <Route path="/bar" element={<Bar/>}/>
     
   
    
   
  
  </Routes>
  </BrowserRouter>
   
   </div>)
}

export default App;